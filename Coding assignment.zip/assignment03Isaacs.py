Users = {
 1: {"First name": "Chinonso ","Last name":"Isaacs","Email address":"mynameischinonso.email","Password": "12345"},
 2: {"First name": "John","Last name":"Doe","Email address":"john.doe.email","Password": "67890"},
 3: {"First name": "Jane ","Last name":"Smith ","Email address":"jane.smith.email","Password": "abcde"},
}
print(Users)

while True:
 userEmail = input("What is your Email address? ")
 userPassword = input("What is your password? ")

 for userId, userInfo in Users.items():
    if userInfo["Email address"] == userEmail and userInfo["Password"] == userPassword:
     print (f"Hello {userInfo['First name']} {userInfo['Last name']}, you have successfully logged in")
     exit()

 print("Incorrect email or password try again")